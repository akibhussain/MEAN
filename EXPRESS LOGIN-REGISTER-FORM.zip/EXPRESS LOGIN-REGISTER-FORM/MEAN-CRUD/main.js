var express = require("express");
var app = express();
// app.use(express.static("Public")); //use static file inbuilt method

// app.get("/", function(req, res) {
//   //base address route
//   res.sendFile(__dirname + "/index.html");
// });

// app.get("/student", function(req, res) {
//   //parametrize route :id
//   //post method is not show on browser//

//   res.send("welcome to student portal ");
// });

// app.post("/student", function(req, res) {
//   //post method is not show on browser//
//   res.send("welcome to student portal");
// });

// app.put("/update", function(req, res) {
//   //post method is not show on browser//
//   res.send(" student portal has been updated");
// });

// app.delete("/delete", function(req, res) {
//   //post method is not show on browser//
//   res.send(" student portal has been delelted");
// });

app.listen(4000, function() {
  console.log("server is runing on 4000 port ");
});
