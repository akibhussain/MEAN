var mongoose = require("mongoose");
mongoose.connect("mongodb://localhost:27017/Employee", {
  useNewUrlParser: true
});

var con = mongoose.connection;

var employeeSchema = new mongoose.Schema({
  name: String,
  address: String,
  mo_no: Number,
  salary: Number
});

var employeeModel = mongoose.model("EmployeeData", employeeSchema);
module.exports = employeeModel;

con.on("connected", function() {
  console.log("connection succsessful");
});

con.on("disconnected", function() {
  console.log("connection not succsessful");
});

con.on("error", console.error.bind(console, "connection error"));
con.once("open", function() {});
