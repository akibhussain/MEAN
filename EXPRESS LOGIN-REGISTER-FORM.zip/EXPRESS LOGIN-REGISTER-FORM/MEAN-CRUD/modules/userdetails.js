var mongoose = require("mongoose");
mongoose.connect("mongodb://localhost:27017/Employee", {
  useNewUrlParser: true,
  useCreateIndex: true
});

var con = mongoose.connection;

var registerschema = new mongoose.Schema({
  email: {
    type: String,
    required: true
  },

  password: {
    type: String,
    required: true
  },

  mno: {
    type: Number,
    required: true,
    index: {
      unique: true
    }
  }

  // email: String,
  // password: String,
  // mno: Number
});

var registerdetails = mongoose.model("registers", registerschema);
module.exports = registerdetails;
con.on("connected", function() {
  console.log("connection succsessful");
});

con.on("disconnected", function() {
  console.log("connection not succsessful");
});

con.on("error", console.error.bind(console, "connection error"));
con.once("open", function() {});
