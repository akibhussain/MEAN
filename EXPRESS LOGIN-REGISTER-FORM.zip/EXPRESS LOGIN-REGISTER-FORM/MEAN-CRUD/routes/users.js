var express = require("express");
var app = express();
app.use(express.static("Public")); //use static file inbuilt method
app.set("view engine", "ejs");
app.set("views", "../views");
var bodyparser = require("body-parser");
var registerdetails = require("../modules/userdetails");
// register = registerdetails.find({});

var router = express.Router();
/* GET home page. */

app.use(bodyparser.urlencoded({ extended: false })); //it encoded the data into url and pass data to body//
app.use(bodyparser.json()); //it recive data in json format//

// sign and signup

app.get("/signin", function(req, res, next) {
  res.render("signin");
});

app.get("/signup", function(req, res, next) {
  res.render("signup", { title: "sign up form", msg: "" });
});

app.post("/signup", function(req, res, next) {
  var email = req.body.email;
  var password = req.body.password;
  var mno = req.body.mno;

  var userdetail = new registerdetails({
    email: email,
    password: password,
    mno: mno
  });
  // console.log(userdetail);
  userdetail.save((err, doc) => {
    if (err) throw err;
    res.render("signup", { title: "sign in", msg: "user register successful" });
  });
});

app.listen(4000, function() {
  console.log("server started on 4000 port");
});

module.exports = router;
