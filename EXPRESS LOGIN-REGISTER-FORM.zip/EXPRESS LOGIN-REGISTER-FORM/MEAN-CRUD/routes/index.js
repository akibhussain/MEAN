var express = require("express");
var app = express();
app.use(express.static("Public")); //use static file inbuilt method
app.set("view engine", "ejs");
app.set("views", "../views");
var bodyparser = require("body-parser");
var bcrypt = require("bcryptjs");

var jwt = require("jsonwebtoken");
if (typeof localStorage === "undefined" || localStorage === null) {
  var LocalStorage = require("node-localstorage").LocalStorage;
  localStorage = new LocalStorage("./scratch");
}

var empModel = require("../modules/employee");
EmployeeData = empModel.find({});

var registerdetails = require("../modules/userdetails");
register = registerdetails.find({});

var router = express.Router();

/* GET home page. */

// middile ware for email checking
function emailcheck(req, res, next) {
  email = req.body.email;
  var checkemail = registerdetails.findOne({ email: email });

  checkemail.exec((err, data) => {
    if (err) throw err;
    if (data) {
      return res.render("signup", {
        title: "USER DETAILS",
        msg: "email alrady exist"
      });
    }
  });
  next();
}

function passwordcheck(req, res, next) {
  password = req.body.password;
  var checkpass = registerdetails.findOne({ password: password });
  checkpass.exec((err, data) => {
    if (err) throw err;
    if (data) {
      return res.render("signup", {
        title: "USER DETAILS",
        msg: "Password alrady exist"
      });
    }
  });
  next();
}

function mobilewordcheck(req, res, next) {
  mno = req.body.mno;
  var checkmno = registerdetails.findOne({ mno: mno });
  checkmno.exec((err, data) => {
    if (err) throw err;
    if (data) {
      return res.render("signup", {
        title: "USER DETAILS",
        msg: "Mobile no alrady exist"
      });
    }
  });
  next();
}

app.use(bodyparser.urlencoded({ extended: false })); //it encoded the data into url and pass data to body//
app.use(bodyparser.json()); //it recive data in json format//

app.get("/", function(req, res, next) {
  EmployeeData.exec(function(err, data) {
    if (err) throw err;
    res.render("index", { title: "USER DETAILS", recods: data });
  });
});

// crud oppreastion postdata
app.post("/", function(req, res, next) {
  var EmpDetails = new empModel({
    name: req.body.uname,
    address: req.body.add,
    mo_no: parseInt(req.body.mno),
    salary: parseInt(req.body.salary)
  });

  // console.log(EmpDetails);

  EmpDetails.save(function(err, res1) {
    EmployeeData.exec(function(err, data) {
      if (err) throw err;
      res.render("index", { title: "USER DETAILS", recods: data });
    });
  });
});

// sign and signup

app.get("/signin", function(req, res, next) {
  res.render("signin", { msg: "" });
});

app.post("/signin", function(req, res, next) {
  var email = req.body.email;
  var password = req.body.password;
  var checkuser = registerdetails.findOne({ email: email });
  checkuser.exec((err, data) => {
    if (err) throw err;

    var getUserID = data._id;
    var getPassword = data.password;
    if (bcrypt.compareSync(password, getPassword)) {
      var token = jwt.sign({ userid: getUserID }, "loginToken");
      localStorage.setItem("usertoken", token);
      localStorage.setItem("loginuser", email);

      res.redirect("/logout");
    } else {
      res.render("signin", { msg: "INVALID USER NAME AND PASSWORD" });
    }
  });
});

app.get("/logout", function(req, res, next) {
  var loginuser = localStorage.getItem(loginuser);
  res.render("logout", { loginuser: loginuser, msg: "" });
});

app.get("/signup", function(req, res, next) {
  res.render("signup", { title: "sign up form", msg: "" });
});

app.post("/signup", emailcheck, passwordcheck, mobilewordcheck, function(
  req,
  res,
  next
) {
  var email = req.body.email;
  var password = req.body.password;
  var confpassword = req.body.confpassword;
  var mno = parseInt(req.body.mno);

  if (password != confpassword) {
    res.render("signup", {
      title: "USER DETAILS",
      msg: "Password does not match!"
    });
  } else {
    password = bcrypt.hashSync(req.body.password, 10);
    var user = new registerdetails({
      email: email,
      password: password,
      mno: mno

      // console.log(user);
    });

    user.save((err, doc) => {
      register.exec(function(err, data) {
        if (err) throw err;
        res.render("signup", {
          title: "USER DETAILS",
          msg: "register sucessfull"
        });
      });
    });
  }
});

app.listen(5000, function() {
  console.log("server started on 5000 port");
});

module.exports = router;
