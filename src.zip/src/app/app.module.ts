import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { AppRoutingModule } from "./app-routing.module";
// import { AppRoutesModule } from "./men/app-routes.module";
import { AppComponent } from "./app.component";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { MainNavComponent } from "./Layout/main-nav/main-nav.component";
import { LayoutModule } from "@angular/cdk/layout";
import { KidsModule } from "./kids/kids/kids.module";

import {
  MatAutocompleteModule,
  MatBadgeModule,
  MatBottomSheetModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatTreeModule
} from "@angular/material";
import { BannerComponent } from "./layout/banner/banner.component";
import { ProductComponent } from "./product/product.component";
import { NavbarComponent } from "./layout/navbar/navbar.component";
import { KidsComponent } from "./kids/kids.component";
import { DropNavbarComponent } from "./layout/drop-navbar/drop-navbar.component";
import { KidsDataService } from "./kids-data.service";
import { HttpClientModule } from "@angular/common/http";
import { Upto12monthComponent } from "./kids/upto12month/upto12month.component";
import { OntTOThreeYearComponent } from "./kids/ont-to-three-year/ont-to-three-year.component";
import { ThreeFourYearsComponent } from "./kids/three-four-years/three-four-years.component";
import { FiveTOsevenComponent } from "./kids/five-toseven/five-toseven.component";
import { EightTOelevenComponent } from "./kids/eight-toeleven/eight-toeleven.component";
import { TwellyearsmoreComponent } from "./kids/twellyearsmore/twellyearsmore.component";
import { FreeShipingBannerComponent } from "./layout/free-shiping-banner/free-shiping-banner.component";
import { ChildComponentComponent } from "./kids/child-component/child-component.component";
import { PagenotfoundComponent } from "./pagenotfound/pagenotfound.component";
import { UserComponent } from "./user/user.component";
import { FormsModule } from "@angular/forms";
import { ReactiveFormsModule } from "@angular/forms";
import { UserService } from "./user.service";
// import { MenModule } from "./men/men.module";

@NgModule({
  declarations: [
    AppComponent,
    MainNavComponent,
    BannerComponent,
    ProductComponent,
    NavbarComponent,
    DropNavbarComponent,
    KidsComponent,
    Upto12monthComponent,
    ThreeFourYearsComponent,
    OntTOThreeYearComponent,
    FiveTOsevenComponent,
    EightTOelevenComponent,
    TwellyearsmoreComponent,
    FreeShipingBannerComponent,
    ChildComponentComponent,
    PagenotfoundComponent,
    UserComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    // AppRoutesModule,
    BrowserAnimationsModule,
    MatSidenavModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatListModule,
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,
    BrowserAnimationsModule,
    HttpClientModule,
    KidsModule,
    // MenModule
    FormsModule,
    ReactiveFormsModule
  ],

  providers: [KidsDataService, UserService],
  bootstrap: [AppComponent]
})
export class AppModule {}
