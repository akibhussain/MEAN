import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-free-shiping-banner',
  templateUrl: './free-shiping-banner.component.html',
  styleUrls: ['./free-shiping-banner.component.css']
})
export class FreeShipingBannerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
