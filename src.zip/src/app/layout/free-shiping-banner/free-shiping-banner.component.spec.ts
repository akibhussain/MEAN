import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FreeShipingBannerComponent } from './free-shiping-banner.component';

describe('FreeShipingBannerComponent', () => {
  let component: FreeShipingBannerComponent;
  let fixture: ComponentFixture<FreeShipingBannerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FreeShipingBannerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FreeShipingBannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
