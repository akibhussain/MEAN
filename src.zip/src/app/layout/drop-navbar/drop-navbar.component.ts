import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-drop-navbar',
  templateUrl: './drop-navbar.component.html',
  styleUrls: ['./drop-navbar.component.css']
})
export class DropNavbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
