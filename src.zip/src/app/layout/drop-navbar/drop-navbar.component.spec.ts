import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DropNavbarComponent } from './drop-navbar.component';

describe('DropNavbarComponent', () => {
  let component: DropNavbarComponent;
  let fixture: ComponentFixture<DropNavbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DropNavbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DropNavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
