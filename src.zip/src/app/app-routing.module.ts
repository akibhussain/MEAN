import { RegisterComponent } from "./register/register/register.component";
import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { KidsComponent } from "./kids/kids.component";
import { Upto12monthComponent } from "./kids/upto12month/upto12month.component";
import { ThreeFourYearsComponent } from "./kids/three-four-years/three-four-years.component";
import { OntTOThreeYearComponent } from "./kids/ont-to-three-year/ont-to-three-year.component";
import { FiveTOsevenComponent } from "./kids/five-toseven/five-toseven.component";
import { EightTOelevenComponent } from "./kids/eight-toeleven/eight-toeleven.component";
import { TwellyearsmoreComponent } from "./kids/twellyearsmore/twellyearsmore.component";
// import { PagenotfoundComponent } from "./pagenotfound/pagenotfound.component";

// preloading concepect

// import { PreloadAllModules } from "@angular/router";
const routes: Routes = [
  {
    path: "kidsrecord",
    component: KidsComponent,

    children: [
      { path: "upto12month", component: Upto12monthComponent },
      { path: "upto12month/:id", component: Upto12monthComponent },
      { path: "1-3-years", component: OntTOThreeYearComponent },
      { path: "3-4-years", component: ThreeFourYearsComponent },
      { path: "5-7-years", component: FiveTOsevenComponent },
      { path: "8-11-years", component: EightTOelevenComponent },
      { path: "12-more", component: TwellyearsmoreComponent }
    ]
  },

  // LAZY LOADING ON MEN COMPONENT//

  {
    path: "men",
    loadChildren: "../app/men/men.module#MenModule",
    data: { preload: true }
  },
  { path: "owen", loadChildren: "../app/owen/owen.module#OwenModule" },
  // { path: "", component: RegisterComponent },
  {
    path: "register",
    loadChildren: "../app/register/register.module#RegisterModule"
  },
  { path: "login", loadChildren: "../app/login/login.module#LoginModule" }

  // { path: "men", component: MenComponent},
  // { path: "**", component: PagenotfoundComponent }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      routes
      //   {
      //   preloadingStrategy: PreloadAllModules
      // }
    )
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
