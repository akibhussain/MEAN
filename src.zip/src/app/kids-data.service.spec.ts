import { TestBed } from '@angular/core/testing';

import { KidsDataService } from './kids-data.service';

describe('KidsDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: KidsDataService = TestBed.get(KidsDataService);
    expect(service).toBeTruthy();
  });
});
