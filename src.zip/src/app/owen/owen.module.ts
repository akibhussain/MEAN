import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { OwmenComponent } from "./owmen/owmen.component";

@NgModule({
  declarations: [OwmenComponent],
  imports: [CommonModule]
})
export class OwenModule {
  constructor() {
    console.log("owmen module loaded");
  }
}
