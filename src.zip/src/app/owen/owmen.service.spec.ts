import { TestBed } from '@angular/core/testing';

import { OwmenService } from './owmen.service';

describe('OwmenService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OwmenService = TestBed.get(OwmenService);
    expect(service).toBeTruthy();
  });
});
