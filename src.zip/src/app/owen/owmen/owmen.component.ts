import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-owmen',
  templateUrl: './owmen.component.html',
  styleUrls: ['./owmen.component.css']
})
export class OwmenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
