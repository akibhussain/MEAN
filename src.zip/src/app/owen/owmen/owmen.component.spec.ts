import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OwmenComponent } from './owmen.component';

describe('OwmenComponent', () => {
  let component: OwmenComponent;
  let fixture: ComponentFixture<OwmenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OwmenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OwmenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
