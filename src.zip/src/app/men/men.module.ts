import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { MenComponent } from "./men/men.component";

@NgModule({
  declarations: [MenComponent],
  imports: [CommonModule],
  exports: [MenComponent]
})
export class MenModule {
  constructor() {
    console.log("Men module loaded");
  }
}
