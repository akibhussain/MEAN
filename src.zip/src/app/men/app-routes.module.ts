import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
// import { MenComponent } from "./men/men.component";
import { Routes } from "@angular/router";
// const routes: Routes = [{ path: "", component: MenComponent }];

@NgModule({
  declarations: [],
  imports: [CommonModule]
})
export class AppRoutesModule {}
