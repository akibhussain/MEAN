import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RegisterComponent } from "./register/register.component";
import { RouterModule, Routes } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

const proRoutes: Routes = [{ path: "", component: RegisterComponent }];

@NgModule({
  declarations: [RegisterComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(proRoutes),
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [RegisterComponent]
})
export class RegisterModule {
  constructor() {
    console.log("register module loaded");
  }
}
