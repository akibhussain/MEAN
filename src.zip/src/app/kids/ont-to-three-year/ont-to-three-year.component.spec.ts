import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OntTOThreeYearComponent } from './ont-to-three-year.component';

describe('OntTOThreeYearComponent', () => {
  let component: OntTOThreeYearComponent;
  let fixture: ComponentFixture<OntTOThreeYearComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OntTOThreeYearComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OntTOThreeYearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
