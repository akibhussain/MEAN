import { Component, OnInit } from "@angular/core";
import { KidsDataService } from "../kids-data.service";

@Component({
  selector: "app-kids",
  templateUrl: "./kids.component.html",
  styleUrls: ["./kids.component.css"],
  providers: [KidsDataService]
})
export class KidsComponent implements OnInit {
  inputvariable = "parent to child exapmple";
  kidrecords: any[];
  KidsDataService: any[];
  constructor(private kidsDataService: KidsDataService) {
    console.log("constructor");
  }

  ngOnInit() {
    this.kidsDataService
      .getkiddata()
      .subscribe(Kidsdata => (this.kidrecords = Kidsdata));
  }
}
