import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-upto12month",
  templateUrl: "./upto12month.component.html",
  styleUrls: ["./upto12month.component.css"]
})
export class Upto12monthComponent implements OnInit {
  constructor() {}

  upto12monthsdatas = [
    {
      name: "Batman costume for kids",
      age: "up-to-12-months",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "police costume for kids",
      age: "up-to-12-months",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "magician costume for kids",
      age: "up-to-12-months",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "ninja costume for kids",
      age: "up-to-12-months",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "Pirate Toddler Costume",
      age: "up-to-12-months",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "lion costume for kids",
      age: "up-to-12-months",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "Best princess costume for kids",
      age: "up-to-12-months",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "puppy costume for kids",
      age: "up-to-12-months",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "sumo-wrestler costume for kids",
      age: "up-to-12-months",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "magician costume for kids",
      age: "up-to-12-months",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "Worker Role Play Costume",
      age: "up-to-12-months",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "Harry Potter costume for kids",
      age: "up-to-12-months",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    }
  ];

  ngOnInit() {}
}
