import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Upto12monthComponent } from './upto12month.component';

describe('Upto12monthComponent', () => {
  let component: Upto12monthComponent;
  let fixture: ComponentFixture<Upto12monthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Upto12monthComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Upto12monthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
