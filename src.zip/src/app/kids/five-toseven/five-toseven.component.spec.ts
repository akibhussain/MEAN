import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FiveTOsevenComponent } from './five-toseven.component';

describe('FiveTOsevenComponent', () => {
  let component: FiveTOsevenComponent;
  let fixture: ComponentFixture<FiveTOsevenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FiveTOsevenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FiveTOsevenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
