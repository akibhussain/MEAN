import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-five-toseven",
  templateUrl: "./five-toseven.component.html",
  styleUrls: ["./five-toseven.component.css"]
})
export class FiveTOsevenComponent implements OnInit {
  constructor() {}

  five_seven_years_datas = [
    {
      name: "Batman costume for kids",
      age: "5-7 years ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "police costume for kids",
      age: "5-7 years ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "magician costume for kids",
      age: "5-7 years ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "ninja costume for kids",
      age: "5-7 years ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "Pirate Toddler Costume",
      age: "5-7 years ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "lion costume for kids",
      age: "5-7 years ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "Best princess costume for kids",
      age: "5-7 years ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "puppy costume for kids",
      age: "5-7 years ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "sumo-wrestler costume for kids",
      age: "5-7 years ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "magician costume for kids",
      age: "5-7 years ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "Worker Role Play Costume",
      age: "5-7 years ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "Harry Potter costume for kids",
      age: "5-7 years ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    }
  ];

  ngOnInit() {}
}
