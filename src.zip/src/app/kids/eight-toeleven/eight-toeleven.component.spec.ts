import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EightTOelevenComponent } from './eight-toeleven.component';

describe('EightTOelevenComponent', () => {
  let component: EightTOelevenComponent;
  let fixture: ComponentFixture<EightTOelevenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EightTOelevenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EightTOelevenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
