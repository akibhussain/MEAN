import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-twellyearsmore",
  templateUrl: "./twellyearsmore.component.html",
  styleUrls: ["./twellyearsmore.component.css"]
})
export class TwellyearsmoreComponent implements OnInit {
  constructor() {}

  twell_more_years_datas = [
    {
      name: "Batman costume for kids",
      age: "12years&more ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "police costume for kids",
      age: "12years&more ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "magician costume for kids",
      age: "12years&more ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "ninja costume for kids",
      age: "12years&more ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "Pirate Toddler Costume",
      age: "12years&more ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "lion costume for kids",
      age: "12years&more ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "Best princess costume for kids",
      age: "12years&more ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "puppy costume for kids",
      age: "12years&more ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "sumo-wrestler costume for kids",
      age: "12years&more ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "magician costume for kids",
      age: "12years&more ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "Worker Role Play Costume",
      age: "12years&more ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "Harry Potter costume for kids",
      age: "12years&more ",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    }
  ];

  ngOnInit() {}
}
