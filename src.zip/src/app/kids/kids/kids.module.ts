import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

// import { KidsComponent } from "../../kids/kids.component";

@NgModule({
  declarations: [],
  imports: [CommonModule]
})
export class KidsModule {}
