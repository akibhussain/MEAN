import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThreeFourYearsComponent } from './three-four-years.component';

describe('ThreeFourYearsComponent', () => {
  let component: ThreeFourYearsComponent;
  let fixture: ComponentFixture<ThreeFourYearsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThreeFourYearsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThreeFourYearsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
