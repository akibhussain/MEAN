import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-three-four-years',
  templateUrl: './three-four-years.component.html',
  styleUrls: ['./three-four-years.component.css']
})
export class ThreeFourYearsComponent implements OnInit {

  constructor() { }


three_four_years_datas = [
    {
      name: "Batman costume for kids",
      age: "3-4 years old",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "police costume for kids",
      age: "3-4 years old",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "magician costume for kids",
      age: "3-4 years old",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "ninja costume for kids",
      age: "3-4 years old",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "Pirate Toddler Costume",
      age: "3-4 years old",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "lion costume for kids",
      age: "3-4 years old",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "Best princess costume for kids",
      age: "3-4 years old",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "puppy costume for kids",
      age: "3-4 years old",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "sumo-wrestler costume for kids",
      age: "3-4 years old",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "magician costume for kids",
      age: "3-4 years old",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "Worker Role Play Costume",
      age: "3-4 years old",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    },

    {
      name: "Harry Potter costume for kids",
      age: "3-4 years old",
      prodimg: "../../../assets/img/3.jpg",
      price: "200"
    }
  ];

  ngOnInit() {
  }

}
