var express = require("express");
var router = express.Router();
var Employee = require("../model/usermodel");
// var emp = Employee.find({});
// var bodyParser = require("body-parser");

// app.use(bodyParser.urlencoded({ extended: false }));

// // parse application/jsonng
// app.use(bodyParser.json());
router.post("/register", function(req, res, next) {
  addToDb(req, res);
});

async function addToDb(req, res) {
  var employee = new Employee({
    fname: req.body.fname,
    lname: req.body.lname,
    email: req.body.email,
    password: Employee.hashPassword(req.body.password)
  });

  try {
    doc = await employee.save();
    return res.status(201).json(doc);
  } catch (err) {
    return res.status(501).json(err);
  }
}
module.exports = router;
