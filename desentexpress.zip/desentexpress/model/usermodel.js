var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var bcrypt = require("bcryptjs");

var schema = new Schema({
  fname: { type: String, require: true },
  lname: { type: String, require: true },
  email: { type: String, require: true },
  passwssord: { type: String, require: true }
});

schema.statics.hashPassword = function hashPassword(password) {
  return bcrypt.hashSync(password, 10);
};

schema.methods.isValid = function(_hashedpassword) {
  return bcrypt.compareSync(_hashedPassword, this.password);
};

module.exports = mongoose.model("user", schema);
